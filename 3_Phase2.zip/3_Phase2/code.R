#project group 3
#please load the reviewData.csv to reviewData
install.packages("plyr")
install.packages("dplyr")
install.packages("leaflet")
library(leaflet)
library(plyr)
library(dplyr)
#subgrouping by business_id and caluculating the average score form given scores. review data has data of review+businessid+ businesscategory = 'Bars'
myResults <- ddply(reviewData, 
                   .(business_id,name,longitude,latitude,city, review_count),
                   summarize, 
                   averageSentimentScore = mean(reviewScore), averageRating=mean(stars)
                   )
View(myResults)
#pal is creation of the palette here with Red-Yellow-Blue colors and 8 variations of those colors.
pal<-colorQuantile("RdYlBu",NULL,n=8)
# '%>%' is composition of functions!, content is creating the info to be displayed for popup. 
content <- paste(sep = "<br/>",myResults$name,
                 paste("Rating:",format(round(myResults$averageRating,2), nsmall=2)),
                 paste("Sentiment:",format(round(myResults$averageSentimentScore,2), nsmall=2)),
                 paste("Total Reviews:",format(round(myResults$review_count,2), nsmall=2)))
map<-leaflet(myResults)%>%addTiles()%>%
  addCircleMarkers(color=~pal(myResults$averageRating),
                   popup=~content, radius = ~sqrt(myResults$review_count)*0.6, 
                   weight = 2,fillOpacity = 0.6, 
                   opacity = 0.8)%>% 
  addProviderTiles("CartoDB.Positron")

#adding the legend.
map%>%addLegend("bottomright", 
                pal = pal, 
                values = ~myResults$review_count,
                title = "Average Review Star Ratings",
                layerId = 2,
                opacity = 1)