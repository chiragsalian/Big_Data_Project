library(shiny)

shinyUI(fluidPage(
  titlePanel("Our Analysis"),
  
  
  sidebarLayout(
      sidebarPanel(
        selectInput("choice1", "Choose a dataset:", 
                    choices = stateData$NAME)
      ),
    mainPanel(
      textOutput("text1"),
      textOutput("text2")
    )
  )
))