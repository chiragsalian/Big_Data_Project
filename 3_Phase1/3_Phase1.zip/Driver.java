import org.json.simple.parser.ParseException;


public class Driver {

	public static void main(String[] args) {
		
		Parser run = new Parser();
		run.dbConnect();
//			run.Read();
	}

}
